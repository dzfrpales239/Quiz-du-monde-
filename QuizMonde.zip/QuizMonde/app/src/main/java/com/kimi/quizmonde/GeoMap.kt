package com.kimi.quizmonde

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/* ==========================================================================
   CARTE INTERACTIVE DU MONDE
   - Polygones simplifies des grands pays
   - Pincement = zoom, glisser = deplacer, toucher = choisir un pays
   ========================================================================== */

fun p(vararg pts: Pair<Double, Double>) = pts.toList()

val MAP_COUNTRIES: Map<String, List<Pair<Double, Double>>> = mapOf(
    "La France" to p(-5.0 to 43.0, -1.0 to 46.0, -1.0 to 49.0, 3.0 to 51.0, 7.0 to 53.0, 8.0 to 48.0, 7.0 to 44.0, 3.0 to 42.0, -1.0 to 43.0),
    "L'Espagne" to p(-9.0 to 43.0, -7.0 to 43.5, -3.0 to 43.5, 0.0 to 40.0, 3.0 to 42.0, 0.0 to 39.0, -2.0 to 37.0, -6.0 to 36.0, -9.0 to 37.0),
    "L'Allemagne" to p(6.0 to 54.0, 8.0 to 55.0, 12.0 to 54.0, 14.0 to 52.0, 14.0 to 50.0, 12.0 to 48.0, 9.0 to 47.0, 7.0 to 47.5, 6.0 to 50.5),
    "L'Italie" to p(8.0 to 44.5, 12.0 to 44.5, 14.0 to 42.0, 16.0 to 40.0, 18.0 to 40.0, 16.0 to 38.0, 15.0 to 40.0, 12.0 to 42.5),
    "Le Royaume-Uni" to p(-5.0 to 50.0, -3.0 to 53.0, -5.0 to 57.5, -3.0 to 58.5, 0.0 to 53.0, 1.0 to 51.0),
    "La Pologne" to p(14.0 to 54.0, 19.0 to 54.5, 23.0 to 52.0, 23.5 to 50.0, 19.0 to 49.0, 15.0 to 49.0, 14.0 to 52.0),
    "La Turquie" to p(26.0 to 40.0, 30.0 to 41.0, 36.0 to 41.0, 41.0 to 41.0, 44.0 to 37.0, 36.0 to 36.0, 30.0 to 37.0),
    "Le Maroc" to p(-13.0 to 35.0, -9.0 to 35.0, -5.0 to 35.5, -5.0 to 31.0, -9.0 to 29.5, -13.0 to 27.5),
    "La Tunisie" to p(8.0 to 37.5, 11.0 to 37.5, 10.0 to 34.0, 8.0 to 32.5, 7.0 to 33.5),
    "Cuba" to p(-84.5 to 22.5, -80.0 to 23.0, -74.5 to 20.5, -77.5 to 20.5, -83.0 to 21.5),
    "Le Chili" to p(-70.0 to -18.0, -68.0 to -23.0, -70.0 to -30.0, -73.0 to -37.0, -74.0 to -44.0, -73.5 to -50.0, -70.5 to -54.0, -70.0 to -48.0, -71.0 to -44.0, -70.0 to -37.0, -68.0 to -30.0, -70.0 to -22.0),
    "Le Pérou" to p(-81.0 to 4.0, -77.0 to -4.0, -75.0 to -10.0, -71.5 to -18.0, -70.0 to -20.0, -75.0 to -15.0, -79.0 to -8.0, -81.0 to -4.0),
    "La Colombie" to p(-77.5 to 8.0, -74.0 to 11.0, -72.0 to 12.0, -68.0 to 11.0, -67.0 to 10.0, -70.0 to 6.0, -74.0 to 5.0, -77.0 to 4.0, -79.0 to 2.0, -78.0 to 7.5),
    "Le Venezuela" to p(-73.0 to 12.0, -68.0 to 11.0, -64.0 to 10.0, -60.0 to 8.0, -61.5 to 5.0, -64.0 to 4.0, -68.0 to 6.0, -72.0 to 8.0),
    "L'Ukraine" to p(22.0 to 48.5, 25.0 to 48.5, 30.0 to 46.0, 33.0 to 46.0, 36.0 to 47.0, 39.5 to 48.0, 40.0 to 46.0, 38.0 to 44.0, 34.0 to 44.0, 32.0 to 45.0, 28.0 to 45.0, 24.0 to 47.0),
    "L'Angola" to p(12.0 to -5.0, 13.0 to -9.0, 14.0 to -14.0, 16.0 to -17.0, 19.0 to -17.0, 22.0 to -14.0, 24.0 to -11.0, 21.0 to -9.0, 18.0 to -6.0, 14.0 to -5.0),
    "La RD Congo" to p(12.0 to 5.0, 13.0 to 0.0, 14.0 to -5.0, 15.0 to -10.0, 17.0 to -11.0, 19.0 to -9.0, 22.0 to -9.0, 24.0 to -6.0, 27.0 to -3.0, 29.0 to -1.0, 27.0 to 3.0, 25.0 to 3.0, 22.0 to 2.0, 19.0 to 2.0, 16.0 to 1.0, 14.0 to 3.0),
    "Le Mexique" to p(-117.0 to 32.5, -111.0 to 31.0, -106.0 to 31.5, -103.0 to 29.0, -100.0 to 27.0, -97.0 to 26.0, -94.0 to 20.0, -90.0 to 16.0, -87.0 to 13.0, -91.0 to 19.0, -97.0 to 24.0, -101.0 to 29.0, -106.0 to 30.0, -110.0 to 31.0),
    "La Norvège" to p(5.0 to 58.0, 8.0 to 58.0, 11.0 to 59.0, 12.0 to 62.0, 14.0 to 65.0, 16.0 to 68.0, 19.0 to 70.0, 25.0 to 71.0, 22.0 to 68.0, 18.0 to 65.0, 14.0 to 61.0, 10.0 to 59.0, 6.0 to 58.5),
    "Le Niger" to p(0.5 to 19.5, 4.0 to 19.0, 9.0 to 16.0, 13.0 to 14.0, 15.0 to 13.5, 14.0 to 11.0, 12.0 to 10.0, 10.0 to 12.0, 7.0 to 13.0, 4.0 to 13.0, 1.0 to 14.0, -2.0 to 15.0, 0.0 to 17.0),
    "Le Mali" to p(-12.0 to 16.5, -8.0 to 15.0, -4.0 to 15.0, -2.0 to 15.0, 0.5 to 16.5, 0.0 to 15.0, 2.0 to 13.0, -1.0 to 13.0, -4.0 to 13.0, -8.0 to 12.0, -12.0 to 14.0),
    "La Mauritanie" to p(-17.0 to 21.0, -13.0 to 21.0, -12.0 to 16.5, -12.0 to 14.0, -16.0 to 16.0),
    "La Guinée" to p(-15.0 to 12.0, -13.0 to 10.0, -10.0 to 8.5, -8.0 to 7.0, -9.0 to 10.0, -12.0 to 12.0),
    /* Grands pays (places a la fin : verifies en dernier) */
    "L'Afrique du Sud" to p(16.0 to -28.5, 19.0 to -33.0, 25.0 to -34.0, 28.5 to -33.0, 31.5 to -29.0, 29.0 to -26.0, 27.0 to -25.0, 22.0 to -25.0, 18.0 to -27.0),
    "L'Arabie Saoudite" to p(34.5 to 29.0, 39.0 to 32.0, 43.0 to 29.0, 48.0 to 27.0, 52.0 to 25.0, 55.0 to 25.0, 58.5 to 23.0, 55.0 to 19.0, 52.0 to 16.0, 47.0 to 14.0, 43.0 to 12.5, 42.0 to 16.0, 39.0 to 21.0, 37.0 to 24.0),
    "L'Égypte" to p(25.0 to 32.0, 30.0 to 31.5, 32.5 to 31.0, 34.2 to 28.0, 35.5 to 23.0, 32.0 to 22.0, 30.0 to 22.0, 27.0 to 22.0, 25.0 to 25.0, 25.0 to 29.0),
    "La Libye" to p(10.0 to 34.0, 20.0 to 32.5, 25.0 to 32.0, 25.0 to 30.0, 23.0 to 27.0, 20.0 to 24.0, 15.0 to 22.5, 12.0 to 23.0, 10.0 to 25.5, 10.0 to 30.0),
    "Le Soudan" to p(25.0 to 22.0, 30.0 to 22.0, 32.0 to 22.0, 35.5 to 23.0, 37.5 to 19.0, 35.0 to 15.0, 33.0 to 14.0, 30.0 to 13.0, 25.0 to 13.0, 24.0 to 15.0, 25.0 to 19.0),
    "L'Algérie" to p(-8.5 to 35.0, -5.0 to 35.0, 0.0 to 36.5, 8.0 to 37.0, 10.0 to 34.0, 9.0 to 30.0, 8.0 to 27.0, 5.0 to 22.0, 0.0 to 20.0, -4.0 to 20.0, -8.5 to 27.0),
    "L'Argentine" to p(-66.0 to -22.0, -63.0 to -25.0, -58.0 to -34.0, -62.0 to -39.0, -65.0 to -45.0, -68.0 to -50.0, -70.5 to -54.0, -73.0 to -50.0, -73.0 to -44.0, -72.0 to -37.0, -70.0 to -30.0),
    "L'Iran" to p(44.0 to 39.5, 48.0 to 38.0, 52.0 to 37.0, 57.0 to 37.5, 60.5 to 37.0, 61.5 to 34.0, 57.0 to 33.0, 53.0 to 29.0, 50.0 to 26.0, 48.0 to 29.0, 46.0 to 32.0, 44.0 to 35.0),
    "Le Canada" to p(-141.0 to 70.0, -128.0 to 70.0, -115.0 to 69.0, -105.0 to 68.0, -96.0 to 68.5, -92.0 to 66.0, -85.0 to 66.0, -80.0 to 62.0, -76.0 to 62.0, -70.0 to 60.0, -64.0 to 58.0, -60.0 to 52.0, -64.0 to 49.0, -60.0 to 47.0, -66.0 to 45.0, -70.0 to 45.0, -75.0 to 45.0, -79.0 to 43.5, -82.0 to 42.0, -84.0 to 46.0, -90.0 to 48.0, -95.0 to 49.0, -103.0 to 49.0, -110.0 to 49.0, -115.0 to 49.0, -120.0 to 49.0, -125.0 to 50.0, -130.0 to 54.0, -135.0 to 57.0, -140.0 to 60.0),
    "Le Brésil" to p(-51.0 to 4.0, -44.0 to -2.0, -38.0 to -5.0, -35.0 to -8.5, -39.0 to -15.0, -40.5 to -22.0, -48.0 to -28.0, -53.0 to -33.0, -57.0 to -30.0, -58.0 to -20.0, -60.0 to -10.0, -63.0 to -3.0, -58.0 to 0.0),
    "L'Inde" to p(68.0 to 24.0, 72.0 to 22.0, 74.0 to 16.0, 77.0 to 8.0, 80.5 to 8.0, 80.0 to 13.0, 84.0 to 19.0, 88.0 to 22.0, 92.0 to 21.0, 90.0 to 25.0, 86.0 to 26.0, 80.0 to 30.0, 76.0 to 32.0, 72.0 to 33.0, 68.0 to 28.0),
    "Le Kazakhstan" to p(46.5 to 48.0, 52.0 to 50.0, 60.0 to 51.0, 66.0 to 48.5, 70.0 to 47.0, 66.0 to 45.0, 62.0 to 42.0, 58.0 to 42.0, 54.0 to 43.0, 50.0 to 44.0, 46.5 to 46.0),
    "La Mongolie" to p(88.0 to 49.0, 94.0 to 49.0, 100.0 to 47.0, 106.0 to 46.0, 112.0 to 45.0, 116.0 to 45.0, 118.5 to 48.0, 112.0 to 50.0, 106.0 to 52.0, 100.0 to 52.0, 94.0 to 50.0),
    "L'Australie" to p(114.0 to -22.0, 114.0 to -30.0, 118.0 to -35.0, 125.0 to -33.0, 130.0 to -32.0, 136.0 to -35.0, 140.0 to -38.0, 146.0 to -39.0, 150.0 to -37.0, 153.0 to -30.0, 153.0 to -25.0, 146.0 to -19.0, 142.0 to -11.0, 136.0 to -12.0, 132.0 to -11.0, 126.0 to -14.0, 122.0 to -17.0),
    "La Chine" to p(74.0 to 40.0, 80.0 to 42.0, 90.0 to 45.0, 97.0 to 43.0, 105.0 to 42.0, 111.0 to 45.0, 118.0 to 46.0, 124.0 to 40.0, 121.0 to 38.0, 117.0 to 38.0, 112.0 to 30.0, 108.0 to 22.0, 102.0 to 22.0, 98.0 to 24.0, 92.0 to 28.0, 85.0 to 29.0, 78.0 to 32.0, 74.0 to 36.0),
    "Les États-Unis" to p(-125.0 to 48.0, -95.0 to 49.0, -88.0 to 48.0, -82.0 to 45.0, -75.0 to 40.0, -76.0 to 35.0, -81.0 to 31.0, -84.0 to 30.0, -90.0 to 29.0, -95.0 to 29.0, -97.0 to 26.0, -101.0 to 26.0, -105.0 to 31.0, -110.0 to 32.0, -114.0 to 33.0, -117.0 to 34.0, -121.0 to 37.0, -124.0 to 42.0, -124.0 to 46.0),
    "La Russie" to p(-10.0 to 36.0, -9.0 to 43.0, -2.0 to 44.0, 0.0 to 46.0, -4.0 to 48.0, -2.0 to 50.0, 5.0 to 53.0, 8.0 to 55.0, 10.0 to 57.0, 18.0 to 56.0, 21.0 to 55.0, 24.0 to 58.0, 28.0 to 60.0, 30.0 to 62.0, 28.0 to 66.0, 32.0 to 70.0, 40.0 to 68.0, 50.0 to 69.0, 60.0 to 69.0, 70.0 to 72.0, 80.0 to 73.0, 90.0 to 75.0, 100.0 to 77.0, 110.0 to 74.0, 120.0 to 73.0, 130.0 to 71.0, 140.0 to 72.0, 150.0 to 70.0, 160.0 to 69.0, 170.0 to 66.0, 178.0 to 65.0, 178.0 to 62.0, 170.0 to 60.0, 162.0 to 58.0, 158.0 to 52.0, 150.0 to 45.0, 142.0 to 42.0, 140.0 to 35.0, 135.0 to 34.0, 129.0 to 33.0, 126.0 to 38.0, 122.0 to 38.0, 120.0 to 32.0, 115.0 to 23.0, 110.0 to 20.0, 108.0 to 12.0, 105.0 to 9.0, 103.0 to 2.0, 100.0 to 8.0, 98.0 to 12.0, 95.0 to 16.0, 92.0 to 16.0, 90.0 to 22.0, 86.0 to 20.0, 80.0 to 15.0, 77.0 to 8.0, 73.0 to 20.0, 70.0 to 22.0, 66.0 to 25.0, 60.0 to 25.0, 56.0 to 26.0, 52.0 to 28.0, 48.0 to 30.0, 44.0 to 29.0, 40.0 to 27.0, 38.0 to 22.0, 35.0 to 28.0, 35.0 to 33.0, 30.0 to 36.0, 26.0 to 38.0, 22.0 to 37.0, 19.0 to 36.0, 15.0 to 38.0, 12.0 to 42.0, 8.0 to 44.0, 3.0 to 43.0, -2.0 to 37.0)
)

val MAPPABLE: List<Pair<String, String>> by lazy {
    MAP_COUNTRIES.keys.mapNotNull { name -> COUNTRIES.firstOrNull { it.first == name } }
}

fun projectPt(lon: Double, lat: Double, w: Float, h: Float): Offset =
    Offset((((lon + 180.0) / 360.0) * w).toFloat(), (((85.0 - lat) / 160.0) * h).toFloat())

fun pointInPolygon(pt: Offset, poly: List<Offset>): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val pi = poly[i]
        val pj = poly[j]
        if (((pi.y > pt.y) != (pj.y > pt.y)) &&
            (pt.x < (pj.x - pi.x) * (pt.y - pi.y) / (pj.y - pi.y) + pi.x)
        ) inside = !inside
        j = i
    }
    return inside
}

fun countryAt(mapPoint: Offset, w: Float, h: Float): String? {
    for ((name, poly) in MAP_COUNTRIES) {
        val projected = poly.map { projectPt(it.first, it.second, w, h) }
        if (pointInPolygon(mapPoint, projected)) return name
    }
    return null
}

/* Carte interactive : pincement = zoom, glisser = deplacer, toucher = choisir.
   Proportions reelles de la Terre (2:1) - pas d'etirement. */
@Composable
fun InteractiveMap(
    highlight: Map<String, Color>,
    onTapCountry: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 6f)
                    offset = Offset(offset.x + pan.x, offset.y + pan.y)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { tap ->
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val mapH = w / 2f
                    val padY = (h - mapH) / 2f
                    val m = Offset(
                        (tap.x - offset.x) / scale,
                        (tap.y - offset.y) / scale - padY
                    )
                    countryAt(m, w, mapH)?.let { onTapCountry(it) }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val mapH = w / 2f
        val padY = (h - mapH) / 2f
        translate(offset.x, offset.y) {
            scale(scale) {
                translate(0f, padY) {
                    drawRect(Color(0xFF0B1526), size = Size(w, mapH))
                    for ((name, poly) in MAP_COUNTRIES) {
                        val path = Path().apply {
                            poly.forEachIndexed { i, pt ->
                                val o = projectPt(pt.first, pt.second, w, mapH)
                                if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y)
                            }
                            close()
                        }
                        val hi = highlight[name]
                        drawPath(path, color = hi ?: Color(0xFF3D5A80))
                        drawPath(
                            path,
                            color = hi ?: Color(0xFF5A7DB5),
                            style = Stroke(width = 1.5f)
                        )
                    }
                }
            }
        }
    }
}


/* ==========================================================================
   GLOBE TERRESTRE 3D : glisser horizontalement = la planete tourne
   ========================================================================== */

fun globeProject(lon: Double, lat: Double, cx: Float, cy: Float, R: Float, rotDeg: Float): Offset? {
    val lam = Math.toRadians(lon) - Math.toRadians(rotDeg)
    val phi = Math.toRadians(lat)
    val x = Math.cos(phi) * Math.sin(lam)
    val y = Math.sin(phi)
    val z = Math.cos(phi) * Math.cos(lam)
    if (z < 0.03) return null
    return Offset(cx + R * x.toFloat(), cy - R * y.toFloat())
}

fun globeCountryAt(tap: Offset, cx: Float, cy: Float, R: Float, rot: Float): String? {
    for ((name, poly) in MAP_COUNTRIES) {
        val front = poly.mapNotNull { globeProject(it.first, it.second, cx, cy, R, rot) }
        if (front.size >= 3 && pointInPolygon(tap, front)) return name
    }
    return null
}

@Composable
fun GlobeView(
    highlight: Map<String, Color>,
    onTapCountry: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var rotation by remember { mutableFloatStateOf(15f) }

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    rotation = (rotation + drag.x * 0.35f) % 360f
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { tap ->
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val R = minOf(cx, cy) * 0.92f
                    globeCountryAt(tap, cx, cy, R, rotation)?.let { onTapCountry(it) }
                }
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val R = minOf(cx, cy) * 0.92f

        // Sphere (ocean)
        drawCircle(Color(0xFF0B1526), radius = R, center = Offset(cx, cy))
        // Halo de la sphere
        drawCircle(
            Color(0xFFFF6B81).copy(alpha = 0.25f),
            radius = R + 4f,
            center = Offset(cx, cy),
            style = Stroke(width = 2f)
        )
        // Equateur
        drawLine(
            Color.White.copy(alpha = 0.12f),
            Offset(cx - R, cy),
            Offset(cx + R, cy),
            strokeWidth = 1f
        )

        // Continents (face visible seulement)
        for ((name, poly) in MAP_COUNTRIES) {
            val front = poly.mapNotNull { globeProject(it.first, it.second, cx, cy, R, rotation) }
            if (front.size >= 3) {
                val path = Path().apply {
                    front.forEachIndexed { i, o ->
                        if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y)
                    }
                    close()
                }
                val hi = highlight[name]
                drawPath(path, color = hi ?: Color(0xFF3D5A80))
                drawPath(
                    path,
                    color = hi ?: Color(0xFF5A7DB5),
                    style = Stroke(width = 1.5f)
                )
            }
        }
    }
}
