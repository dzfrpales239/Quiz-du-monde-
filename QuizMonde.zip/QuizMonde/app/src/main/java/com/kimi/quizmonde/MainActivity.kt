package com.kimi.quizmonde

import android.content.Context
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/* ==========================================================================
   QUIZ DU MONDE — Jeu de culture generale
   6 themes x 3 difficultes, sons, score, enchainements, chrono Expert
   ========================================================================== */

val BgBrush = Brush.verticalGradient(
    listOf(Color(0xFF12082B), Color(0xFF05070F))
)
val Turquoise = Color(0xFF00E5FF)
val GoodGreen = Color(0xFF00C853)
val BadRed = Color(0xFFFF5252)

/* Sons partages */
object Sfx {
    var tap: () -> Unit = {}
    var good: () -> Unit = {}
    var bad: () -> Unit = {}
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Turquoise, secondary = Color(0xFF7C4DFF))) {
                QuizApp()
            }
        }
    }
}

@Composable
fun QuizApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("quiz_prefs", Context.MODE_PRIVATE) }
    val pool = remember { SoundPool.Builder().setMaxStreams(4).build() }
    val ids = remember {
        listOf(
            pool.load(context, R.raw.goutte, 1),
            pool.load(context, R.raw.success, 1),
            pool.load(context, R.raw.error, 1),
            pool.load(context, R.raw.bulle, 1)
        )
    }
    Sfx.tap = { pool.play(ids[0], 1f, 1f, 1, 0, 1f) }
    Sfx.good = { pool.play(ids[1], 1f, 1f, 1, 0, 1f) }
    Sfx.bad = { pool.play(ids[2], 1f, 1f, 1, 0, 1f) }

    var screen by remember { mutableStateOf("menu") }
    var themeKey by remember { mutableStateOf("") }
    var difficulty by remember { mutableIntStateOf(0) }
    var questions by remember { mutableStateOf<List<Q>>(emptyList()) }
    var finalScore by remember { mutableIntStateOf(0) }
    var finalStreak by remember { mutableIntStateOf(0) }
    var gameCompleted by remember { mutableStateOf(true) }
    var distStart by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showDiff by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(BgBrush)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(400.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF7C4DFF).copy(alpha = 0.2f), Color.Transparent),
                        radius = 850f
                    )
                )
        )

        when (screen) {
            "menu" -> MenuScreen(
                best = { t, d -> prefs.getInt("best_" + t + "_" + d, 0) },
                onTheme = { t -> themeKey = t; showDiff = true }
            )
            "quiz" -> QuizScreen(
                questions = questions,
                difficulty = difficulty,
                onFinish = { s, st, completed ->
                    finalScore = s
                    finalStreak = st
                    gameCompleted = completed
                    val k = "best_" + themeKey + "_" + difficulty
                    if (s > prefs.getInt(k, 0)) prefs.edit().putInt(k, s).apply()
                    screen = "result"
                },
                onQuit = { screen = "menu" }
            )
            "diststart" -> DistStartScreen(
                onPick = { c -> distStart = c; screen = "distgame" },
                onBack = { screen = "menu" }
            )
            "distgame" -> distStart?.let { st ->
                DistGameScreen(
                    start = st,
                    onFinish = { s, lost ->
                        finalScore = s
                        finalStreak = 0
                        gameCompleted = !lost
                        screen = "result"
                    },
                    onQuit = { screen = "menu" }
                )
            }
            "result" -> ResultScreen(
                score = finalScore,
                total = questions.size * 10,
                streak = finalStreak,
                completed = gameCompleted,
                onReplay = {
                    questions = QuizData.pick(themeKey, difficulty)
                    screen = "quiz"
                },
                onMenu = { screen = "menu" }
            )
        }

        if (showDiff) {
            DifficultyDialog(
                theme = QuizData.THEMES.firstOrNull { it.key == themeKey } ?: QuizData.THEMES[0],
                onPick = { d ->
                    difficulty = d
                    questions = QuizData.pick(themeKey, d)
                    Sfx.tap()
                    showDiff = false
                    screen = "quiz"
                },
                onDismiss = { showDiff = false }
            )
        }
    }
}

/* ---------- Ecran d'accueil ---------- */

@Composable
fun MenuScreen(best: (String, Int) -> Int, onTheme: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text(
            "Quiz du Monde",
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = (-1).sp
        )
        Text(
            "Choisis un theme et teste tes connaissances",
            fontSize = 14.sp,
            color = Turquoise.copy(alpha = 0.85f)
        )
        Spacer(Modifier.height(24.dp))

        QuizData.THEMES.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { t ->
                    val b0 = best(t.key, 0)
                    val b1 = best(t.key, 1)
                    val b2 = best(t.key, 2)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color.White.copy(alpha = 0.07f))
                            .clickable { Sfx.tap(); onTheme(t.key) }
                            .padding(vertical = 20.dp, horizontal = 10.dp)
                    ) {
                        Text(t.emoji, fontSize = 40.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            t.label,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Record : " + maxOf(b0, b1, b2) + " pts",
                            fontSize = 11.sp,
                            color = Turquoise.copy(alpha = 0.75f)
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
        }

        // Mode special : Defi Distance
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Turquoise.copy(alpha = 0.14f))
                .clickable { Sfx.tap(); screen = "diststart" }
                .padding(16.dp)
        ) {
            Text("✈️", fontSize = 34.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Défi Distance", color = Turquoise, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                Text(
                    "Choisis ton pays de départ, devine les pays à la bonne distance. 6 cœurs !",
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

/* ---------- Choix du pays de départ ---------- */

@Composable
fun DistStartScreen(onPick: (Pair<String, String>) -> Unit, onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("✕", color = Color.White.copy(alpha = 0.5f), fontSize = 18.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onBack() }.padding(6.dp))
            Spacer(Modifier.width(12.dp))
            Text("✈️ Défi Distance", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        Text("Choisis ton pays de départ", fontSize = 14.sp, color = Turquoise.copy(alpha = 0.85f))
        Spacer(Modifier.height(18.dp))

        QuizData.COUNTRIES.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { c ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(78.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { Sfx.tap(); onPick(c) }
                            .padding(vertical = 8.dp)
                    ) {
                        Text(c.second, fontSize = 34.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            c.first.replace("Les ", "").replace("La ", "").replace("Le ", "").replace("L'", ""),
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.75f),
                            maxLines = 1
                        )
                    }
                }
                for (i in row.size until 4) Spacer(Modifier.width(78.dp))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/* ---------- Jeu du Defi Distance ---------- */

@Composable
fun DistGameScreen(
    start: Pair<String, String>,
    onFinish: (Int, Boolean) -> Unit,
    onQuit: () -> Unit
) {
    val startCoords = QuizData.CAPITAL_COORDS[start.first] ?: return
    val destinations = remember {
        QuizData.COUNTRIES.filter { it.first != start.first }.shuffled().take(10)
    }

    var round by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(6) }
    var selected by remember { mutableStateOf(-1) }
    var answered by remember { mutableStateOf(false) }

    val current = destinations[round]
    val distKm = Math.round(QuizData.haversineKm(startCoords, QuizData.CAPITAL_COORDS[current.first]!!) / 100.0) * 100

    val options = remember(current) {
        val others = destinations.filter { it.first != current.first }.shuffled().take(3)
        (listOf(current) + others).shuffled()
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("✕", color = Color.White.copy(alpha = 0.5f), fontSize = 18.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onQuit() }.padding(6.dp))
            Spacer(Modifier.weight(1f))
            Text("Défi " + (round + 1) + "/" + destinations.size, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text("🏆 " + score, color = Turquoise, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            for (i in 0 until 6) Text(if (i < lives) "❤️" else "🖤", fontSize = 14.sp)
        }
        if (streak >= 3) {
            Text("🔥 Serie x" + streak + " (points doubles !)", color = Color(0xFFFFB300), fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { round / destinations.size.toFloat() },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
            color = Turquoise,
            trackColor = Color.White.copy(alpha = 0.1f)
        )

        Spacer(Modifier.height(28.dp))

        Text("✈️ Tu pars de :", color = Color.White.copy(alpha = 0.6f), fontSize = 15.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(6.dp))
        Text(start.second, fontSize = 64.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text(start.first, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(18.dp))

        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(20.dp))
                .background(Turquoise.copy(alpha = 0.14f))
                .padding(horizontal = 22.dp, vertical = 12.dp)
        ) {
            Text("≈ " + distKm + " km en avion", color = Turquoise, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(10.dp))
        Text("Quel pays se trouve à cette distance ?", color = Color.White, fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.CenterHorizontally))

        Spacer(Modifier.height(20.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            options.forEachIndexed { i, opt ->
                val isCorrect = opt.first == current.first
                val bg = when {
                    answered && i == selected && isCorrect -> GoodGreen.copy(alpha = 0.35f)
                    answered && i == selected && !isCorrect -> BadRed.copy(alpha = 0.35f)
                    answered && isCorrect -> GoodGreen.copy(alpha = 0.2f)
                    else -> Color.White.copy(alpha = 0.08f)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(bg)
                        .clickable(enabled = !answered) {
                            Sfx.tap()
                            selected = i
                            answered = true
                            if (isCorrect) {
                                score += if (streak >= 3) 20 else 10
                                streak++
                                Sfx.good()
                            } else {
                                streak = 0
                                lives--
                                Sfx.bad()
                            }
                        }
                        .padding(13.dp)
                ) {
                    Text(
                        if (isCorrect && answered) "✅  " else if (i == selected && answered && !isCorrect) "❌  " else opt.second + "  ",
                        fontSize = 15.sp
                    )
                    Text(opt.first, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(Modifier.weight(1f))

        if (answered) {
            TextButton(
                onClick = {
                    Sfx.tap()
                    if (lives <= 0 || round + 1 >= destinations.size) onFinish(score, lives <= 0)
                    else {
                        round++
                        selected = -1
                        answered = false
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(
                    if (lives <= 0) "Terminer" else if (round + 1 >= destinations.size) "Voir le resultat" else "Suivant",
                    color = Turquoise, fontSize = 16.sp, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

/* ---------- Choix de la difficulte ---------- */

@Composable
fun DifficultyDialog(theme: Theme, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(theme.emoji + "  " + theme.label, color = Color.White) },
        text = {
            Column {
                Text("Choisis ta difficulte", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                listOf(
                    Triple("😊", "Facile", "4 choix, questions classiques"),
                    Triple("🤨", "Moyen", "5 choix, melange de questions"),
                    Triple("🔥", "Expert", "6 choix + chrono 15 s + bonus serie")
                ).forEachIndexed { i, opt ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .clickable { onPick(i) }
                            .padding(12.dp)
                    ) {
                        Text(opt.first, fontSize = 22.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(opt.second, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(opt.third, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

/* ---------- Ecran du quiz ---------- */

@Composable
fun QuizScreen(
    questions: List<Q>,
    difficulty: Int,
    onFinish: (Int, Int, Boolean) -> Unit,
    onQuit: () -> Unit
) {
    if (questions.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Pas assez de questions pour ce theme.", color = Color.White)
            TextButton(onClick = onQuit) { Text("Retour") }
        }
        return
    }

    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var bestStreak by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(-1) }
    var answered by remember { mutableStateOf(false) }
    var timeLeft by remember { mutableIntStateOf(15) }

    val q = questions[index]
    val count = QuizData.optionCount(difficulty)
    val options = remember(q) { QuizData.buildOptions(q, count) }

    if (difficulty == 2) {
        LaunchedEffect(index) {
            timeLeft = 15
            while (timeLeft > 0) {
                delay(1000)
                if (answered) break
                timeLeft--
            }
            if (!answered) {
                selected = -2
                answered = true
                streak = 0
                Sfx.bad()
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("✕", color = Color.White.copy(alpha = 0.5f), fontSize = 18.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onQuit() }.padding(6.dp))
            Spacer(Modifier.weight(1f))
            Text("Question " + (index + 1) + "/" + questions.size, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text("🏆 " + score, color = Turquoise, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (streak >= 3) {
            Spacer(Modifier.height(4.dp))
            Text("🔥 Serie x" + streak + "  (points doubles !)", color = Color(0xFFFFB300), fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { index / questions.size.toFloat() },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
            color = Turquoise,
            trackColor = Color.White.copy(alpha = 0.1f)
        )
        if (difficulty == 2) {
            Spacer(Modifier.height(6.dp))
            Text(
                "⏱ " + timeLeft + " s",
                color = if (timeLeft <= 5) BadRed else Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(24.dp))

        if (q.icon.isNotEmpty()) {
            Text(q.icon, fontSize = 96.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
        }
        Text(
            q.text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(Modifier.height(26.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            options.forEachIndexed { i, opt ->
                val isCorrect = opt == q.answer
                val bg = when {
                    answered && i == selected && isCorrect -> GoodGreen.copy(alpha = 0.35f)
                    answered && i == selected && !isCorrect -> BadRed.copy(alpha = 0.35f)
                    answered && isCorrect -> GoodGreen.copy(alpha = 0.2f)
                    else -> Color.White.copy(alpha = 0.08f)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(bg)
                        .clickable(enabled = !answered) {
                            Sfx.tap()
                            selected = i
                            answered = true
                            if (isCorrect) {
                                val bonus = if (streak >= 3) 20 else 10
                                score += bonus
                                streak++
                                if (streak > bestStreak) bestStreak = streak
                                Sfx.good()
                            } else {
                                streak = 0
                                Sfx.bad()
                            }
                        }
                        .padding(14.dp)
                ) {
                    Text(
                        (if (isCorrect && answered) "✅  " else if (i == selected && answered && !isCorrect) "❌  " else "•  "),
                        fontSize = 15.sp
                    )
                    Text(opt, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        if (selected == -2 && answered) {
            Spacer(Modifier.height(10.dp))
            Text("⏱ Temps ecoule ! La reponse etait : " + q.answer, color = BadRed, fontSize = 13.sp)
        }

        Spacer(Modifier.weight(1f))

        if (answered) {
            TextButton(
                onClick = {
                    Sfx.tap()
                    if (index + 1 >= questions.size) onFinish(score, bestStreak, true)
                    else {
                        index++
                        selected = -1
                        answered = false
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(
                    if (index + 1 >= questions.size) "Voir le resultat" else "Suivant",
                    color = Turquoise,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

/* ---------- Ecran de resultat ---------- */

@Composable
fun ResultScreen(score: Int, total: Int, streak: Int, completed: Boolean, onReplay: () -> Unit, onMenu: () -> Unit) {
    val pct = if (total > 0) score * 100 / total else 0
    val (emoji, msg) = if (!completed) {
        "💔" to "Partie terminee : 6 fautes !"
    } else when {
        pct >= 80 -> "🏆" to "Excellent ! Maitre du quiz !"
        pct >= 60 -> "🎉" to "Beau travail !"
        pct >= 40 -> "💪" to "Pas mal, continue !"
        else -> "📚" to "Courage, reessaie !"
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 84.sp)
        Spacer(Modifier.height(16.dp))
        Text(score.toString() + " / " + total, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, color = Turquoise)
        Text("points", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Text(msg, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        if (streak >= 3) {
            Spacer(Modifier.height(8.dp))
            Text("Meilleure serie : 🔥 x" + streak, color = Color(0xFFFFB300), fontSize = 15.sp)
        }
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(
                onClick = { Sfx.tap(); onReplay() },
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.1f)).padding(horizontal = 8.dp)
            ) { Text("Rejouer", color = Turquoise, fontWeight = FontWeight.Bold) }
            TextButton(
                onClick = { Sfx.tap(); onMenu() },
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.1f)).padding(horizontal = 8.dp)
            ) { Text("Menu", color = Color.White, fontWeight = FontWeight.Bold) }
        }
    }
}
