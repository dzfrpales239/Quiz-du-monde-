package com.kimi.quizmonde

/* ==========================================================================
   QUIZ DU MONDE — Banque de questions
   Themes : Drapeaux, Capitales, Monuments, Histoire, Palestine, Vrai ou Faux
   ========================================================================== */

data class Q(val theme: String, val text: String, val answer: String, val icon: String = "", val hard: Boolean = false)

object QuizData {
    const val DRAPEAUX = "Drapeaux"
    const val CAPITALES = "Capitales"
    const val MONUMENTS = "Monuments"
    const val HISTOIRE = "Histoire"
    const val PALESTINE = "Palestine"
    const val VF = "Vrai ou Faux"
    const val SUPERFICIE = "Superficie"
    const val POPULATION = "Population"
    const val DISTANCES = "Distances avion"

    val THEMES = listOf(
        Theme("🌍", DRAPEAUX, "Drapeaux du monde"),
        Theme("🏛️", CAPITALES, "Capitales"),
        Theme("🗼", MONUMENTS, "Monuments"),
        Theme("📜", HISTOIRE, "Histoire du monde"),
        Theme("🕊️", PALESTINE, "Histoire de la Palestine"),
        Theme("⚖️", VF, "Vrai ou Faux"),
        Theme("🏜️", SUPERFICIE, "Superficie des pays"),
        Theme("👥", POPULATION, "Population"),
    )

    val ALL: List<Q> = listOf(
        /* ---------- DRAPEAUX ---------- */
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La France", "🇫🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Japon", "🇯🇵"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Brésil", "🇧🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Algérie", "🇩🇿"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Maroc", "🇲🇦"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Tunisie", "🇹🇳"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Palestine", "🇵🇸"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Égypte", "🇪🇬"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Arabie Saoudite", "🇸🇦"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Turquie", "🇹🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Italie", "🇮🇹"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Allemagne", "🇩🇪"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Les États-Unis", "🇺🇸"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Chine", "🇨🇳"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Inde", "🇮🇳"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Espagne", "🇪🇸"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Royaume-Uni", "🇬🇧"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Russie", "🇷🇺"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Canada", "🇨🇦"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Australie", "🇦🇺"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Grèce", "🇬🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Mexique", "🇲🇽"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Argentine", "🇦🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Corée du Sud", "🇰🇷"),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Qatar", "🇶🇦", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Les Émirats arabes unis", "🇦🇪", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Suède", "🇸🇪", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Kenya", "🇰🇪", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Nigéria", "🇳🇬", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Pakistan", "🇵🇰", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "L'Indonésie", "🇮🇩", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "La Thaïlande", "🇹🇭", hard = true),
        Q(DRAPEAUX, "Quel pays a ce drapeau ?", "Le Vietnam", "🇻🇳", hard = true),

        /* ---------- CAPITALES ---------- */
        Q(CAPITALES, "Quelle est la capitale de la France ?", "Paris"),
        Q(CAPITALES, "Quelle est la capitale du Japon ?", "Tokyo"),
        Q(CAPITALES, "Quelle est la capitale de l'Algérie ?", "Alger"),
        Q(CAPITALES, "Quelle est la capitale de l'Égypte ?", "Le Caire"),
        Q(CAPITALES, "Quelle est la capitale de l'Italie ?", "Rome"),
        Q(CAPITALES, "Quelle est la capitale de l'Allemagne ?", "Berlin"),
        Q(CAPITALES, "Quelle est la capitale de l'Espagne ?", "Madrid"),
        Q(CAPITALES, "Quelle est la capitale du Royaume-Uni ?", "Londres"),
        Q(CAPITALES, "Quelle est la capitale de la Russie ?", "Moscou"),
        Q(CAPITALES, "Quelle est la capitale de la Chine ?", "Pékin"),
        Q(CAPITALES, "Quelle est la capitale des États-Unis ?", "Washington"),
        Q(CAPITALES, "Quelle est la capitale du Canada ?", "Ottawa"),
        Q(CAPITALES, "Quelle est la capitale de la Grèce ?", "Athènes"),
        Q(CAPITALES, "Quelle est la capitale du Mexique ?", "Mexico"),
        Q(CAPITALES, "Quelle est la capitale de l'Argentine ?", "Buenos Aires"),
        Q(CAPITALES, "Quelle est la capitale de la Corée du Sud ?", "Séoul"),
        Q(CAPITALES, "Quelle est la capitale du Portugal ?", "Lisbonne"),
        Q(CAPITALES, "Quelle est la capitale de la Belgique ?", "Bruxelles"),
        Q(CAPITALES, "Quelle est la capitale de la Suisse ?", "Berne", hard = true),
        Q(CAPITALES, "Quelle est la capitale de la Turquie ?", "Ankara", hard = true),
        Q(CAPITALES, "Quelle est la capitale du Maroc ?", "Rabat", hard = true),
        Q(CAPITALES, "Quelle est la capitale de la Tunisie ?", "Tunis", hard = true),
        Q(CAPITALES, "Quelle est la capitale de l'Australie ?", "Canberra", hard = true),
        Q(CAPITALES, "Quelle est la capitale du Brésil ?", "Brasília", hard = true),
        Q(CAPITALES, "Quelle est la capitale de l'Arabie Saoudite ?", "Riyad", hard = true),
        Q(CAPITALES, "Quelle est la capitale du Qatar ?", "Doha", hard = true),
        Q(CAPITALES, "Quelle est la capitale des Émirats ?", "Abou Dabi", hard = true),
        Q(CAPITALES, "Quelle est la capitale du Nigéria ?", "Abuja", hard = true),
        Q(CAPITALES, "Quelle est la capitale du Kenya ?", "Nairobi", hard = true),
        Q(CAPITALES, "Quelle est la capitale de la Suède ?", "Stockholm", hard = true),
        Q(CAPITALES, "Quelle est la capitale de la Palestine ?", "Jérusalem-Est"),

        /* ---------- MONUMENTS ---------- */
        Q(MONUMENTS, "Dans quelle ville se trouve la Tour Eiffel ?", "Paris"),
        Q(MONUMENTS, "Dans quelle ville se trouve le Colisée ?", "Rome"),
        Q(MONUMENTS, "Dans quelle ville se trouve Big Ben ?", "Londres"),
        Q(MONUMENTS, "Dans quelle ville se trouve la Statue de la Liberté ?", "New York"),
        Q(MONUMENTS, "Dans quelle ville se trouve le Taj Mahal ?", "Agra", hard = true),
        Q(MONUMENTS, "Dans quelle ville se trouve la Sagrada Família ?", "Barcelone"),
        Q(MONUMENTS, "Dans quelle ville se trouve le Christ Rédempteur ?", "Rio de Janeiro"),
        Q(MONUMENTS, "Dans quelle ville se trouve le Burj Khalifa ?", "Dubaï", hard = true),
        Q(MONUMENTS, "Où se trouve la mosquée Al-Aqsa ?", "Jérusalem"),
        Q(MONUMENTS, "Dans quel pays se trouve la Grande Muraille ?", "La Chine"),
        Q(MONUMENTS, "Dans quel pays se trouvent les pyramides de Gizeh ?", "L'Égypte"),
        Q(MONUMENTS, "Dans quel pays se trouve le Machu Picchu ?", "Le Pérou", hard = true),
        Q(MONUMENTS, "Dans quel pays se trouve le Mont Saint-Michel ?", "La France"),
        Q(MONUMENTS, "Dans quelle ville se trouve la Tour de Pise ?", "Pise", hard = true),

        /* ---------- HISTOIRE DU MONDE ---------- */
        Q(HISTOIRE, "En quelle année la Première Guerre mondiale a-t-elle commencé ?", "1914"),
        Q(HISTOIRE, "En quelle année la Seconde Guerre mondiale s'est-elle terminée ?", "1945"),
        Q(HISTOIRE, "Qui a découvert l'Amérique en 1492 ?", "Christophe Colomb"),
        Q(HISTOIRE, "En quelle année la Révolution française a-t-elle commencé ?", "1789"),
        Q(HISTOIRE, "Qui était le premier empereur des Français ?", "Napoléon Bonaparte"),
        Q(HISTOIRE, "En quelle année l'homme a-t-il marché sur la Lune ?", "1969"),
        Q(HISTOIRE, "Quel mur est tombé en 1989 ?", "Le mur de Berlin"),
        Q(HISTOIRE, "Qui a peint la Joconde ?", "Léonard de Vinci"),
        Q(HISTOIRE, "En quelle année l'esclavage a-t-il été aboli en France ?", "1848"),
        Q(HISTOIRE, "Quelle civilisation a construit les pyramides du Mexique ?", "Les Mayas", hard = true),
        Q(HISTOIRE, "En quelle année l'URSS s'est-elle dissoute ?", "1991", hard = true),
        Q(HISTOIRE, "Qui a écrit le roman Les Misérables ?", "Victor Hugo"),
        Q(HISTOIRE, "En quelle année le premier iPhone est-il sorti ?", "2007", hard = true),
        Q(HISTOIRE, "La construction de la Grande Muraille a commencé sous quelle dynastie ?", "Les Qin", hard = true),

        /* ---------- HISTOIRE DE LA PALESTINE ---------- */
        Q(PALESTINE, "En quelle année la déclaration Balfour a-t-elle été publiée ?", "1917"),
        Q(PALESTINE, "En quelle année la Nakba a-t-elle eu lieu ?", "1948"),
        Q(PALESTINE, "Que signifie « Nakba » en arabe ?", "La catastrophe"),
        Q(PALESTINE, "En quelle année la Guerre des Six Jours a-t-elle eu lieu ?", "1967"),
        Q(PALESTINE, "Quelle grande mosquée se trouve à Jérusalem ?", "Al-Aqsa"),
        Q(PALESTINE, "Quelle est la capitale revendiquée par la Palestine ?", "Jérusalem-Est"),
        Q(PALESTINE, "En quelle année l'OLP a-t-elle été créée ?", "1964"),
        Q(PALESTINE, "Environ combien de Palestiniens sont devenus réfugiés en 1948 ?", "Environ 700 000"),
        Q(PALESTINE, "Quel territoire palestinien est bordé par la mer Méditerranée ?", "Gaza"),
        Q(PALESTINE, "Quel pays borde la Cisjordanie à l'est ?", "La Jordanie"),
        Q(PALESTINE, "En quelle année l'accord d'Oslo a-t-il été signé ?", "1993", hard = true),
        Q(PALESTINE, "En quelle année la construction du mur de séparation a-t-elle commencé ?", "2002", hard = true),

        /* ---------- SUPERFICIE ---------- */
        Q(SUPERFICIE, "Quel est le plus grand pays du monde par sa superficie ?", "La Russie"),
        Q(SUPERFICIE, "Quel est le deuxième plus grand pays du monde ?", "Le Canada"),
        Q(SUPERFICIE, "Quel est le plus grand pays d'Afrique ?", "L'Algérie"),
        Q(SUPERFICIE, "Quel est le plus grand pays d'Amérique du Sud ?", "Le Brésil"),
        Q(SUPERFICIE, "Quel est le plus grand pays arabe du monde ?", "L'Algérie"),
        Q(SUPERFICIE, "La superficie de la Russie est d'environ…", "17 millions de km²"),
        Q(SUPERFICIE, "La superficie de l'Algérie est d'environ…", "2,4 millions de km²"),
        Q(SUPERFICIE, "Quel est le plus petit pays du monde ?", "Le Vatican", hard = true),
        Q(SUPERFICIE, "Quel est le plus grand pays entierement situe en Asie ?", "La Chine", hard = true),
        Q(SUPERFICIE, "Quel est le plus grand pays du monde sans acces a la mer ?", "Le Kazakhstan", hard = true),

        /* ---------- POPULATION ---------- */
        Q(POPULATION, "Quel est le pays le plus peuple du monde ?", "L'Inde"),
        Q(POPULATION, "Quel pays a ete depasse par l'Inde en population ?", "La Chine"),
        Q(POPULATION, "Quel est le pays le plus peuple d'Afrique ?", "Le Nigeria"),
        Q(POPULATION, "Quel est le pays le plus peuple du monde arabe ?", "L'Egypte"),
        Q(POPULATION, "Quel pays compte environ 330 millions d'habitants ?", "Les États-Unis"),
        Q(POPULATION, "Quel pays compte environ 280 millions d'habitants ?", "L'Indonesie", hard = true),
        Q(POPULATION, "Quel est le pays le plus peuple d'Europe ?", "La Russie"),
        Q(POPULATION, "Quel est le deuxième pays le plus peuple d'Amerique du Sud ?", "La Colombie", hard = true),
        Q(POPULATION, "Quel pays compte environ 220 millions d'habitants ?", "Le Bresil", hard = true),
        Q(POPULATION, "Quel pays compte environ 120 millions d'habitants ?", "Le Mexique", hard = true),

        /* ---------- DISTANCES AVION ---------- */
        Q(DISTANCES, "Distance en avion Paris - Alger ?", "Environ 1 400 km"),
        Q(DISTANCES, "Distance en avion Paris - New York ?", "Environ 5 800 km"),
        Q(DISTANCES, "Distance en avion Paris - Tokyo ?", "Environ 9 800 km"),
        Q(DISTANCES, "Distance en avion Paris - Dubaï ?", "Environ 5 200 km"),
        Q(DISTANCES, "Distance en avion Alger - Le Caire ?", "Environ 2 700 km"),
        Q(DISTANCES, "Distance en avion Paris - Rabat ?", "Environ 1 800 km"),
        Q(DISTANCES, "Distance en avion Le Caire - Istanbul ?", "Environ 1 200 km"),
        Q(DISTANCES, "Distance en avion Paris - Moscou ?", "Environ 2 500 km"),
        Q(DISTANCES, "Distance en avion Paris - Bangkok ?", "Environ 9 400 km", hard = true),
        Q(DISTANCES, "Distance en avion Alger - Dakar ?", "Environ 3 200 km", hard = true),
        Q(DISTANCES, "Distance en avion Paris - Sydney ?", "Environ 17 000 km", hard = true),
        Q(DISTANCES, "Distance en avion Paris - Le Caire ?", "Environ 3 200 km", hard = true),

        /* ---------- VRAI OU FAUX ---------- */
        Q(VF, "La Russie est le plus grand pays d'Europe.", "Vrai"),
        Q(VF, "Le Sahara est le plus grand désert du monde.", "Vrai"),
        Q(VF, "La langue la plus parlée au monde est l'anglais.", "Faux"),
        Q(VF, "La capitale de l'Australie est Sydney.", "Faux"),
        Q(VF, "Les pyramides de Gizeh se trouvent en Algérie.", "Faux"),
        Q(VF, "La capitale de la Suisse est Zurich.", "Faux"),
        Q(VF, "La Palestine est membre observateur à l'ONU.", "Vrai", hard = true),
        Q(VF, "Le kéfié est un vêtement traditionnel palestinien.", "Vrai"),
        Q(VF, "La mer Morte est le point le plus bas de la Terre.", "Vrai", hard = true),
        Q(VF, "La Turquie a sa capitale à Istanbul.", "Faux", hard = true),
        Q(VF, "Le Brésil est le plus grand pays d'Amérique du Sud.", "Vrai"),
        Q(VF, "Le football est le sport le plus populaire au monde.", "Vrai")
    )

    fun pick(theme: String, difficulty: Int): List<Q> {
        val pool = ALL.filter { it.theme == theme }
        val easy = pool.filter { !it.hard }
        val hard = pool.filter { it.hard }
        return when (difficulty) {
            0 -> easy.shuffled().take(10).ifEmpty { pool.shuffled().take(10) }
            1 -> pool.shuffled().take(10)
            else -> (hard + easy).shuffled().take(10).ifEmpty { pool.shuffled().take(10) }
        }
    }

    fun optionCount(difficulty: Int): Int = when (difficulty) {
        0 -> 4
        1 -> 5
        else -> 6
    }

    fun buildOptions(q: Q, count: Int): List<String> {
        if (q.theme == VF) return listOf("Vrai", "Faux")
        val pool = ALL.filter { it.theme == q.theme && it.answer != q.answer }.map { it.answer }.distinct()
        return (listOf(q.answer) + pool.shuffled().take(count - 1)).shuffled()
    }
}



/* ---------- Defi Distance : coordonnees des capitales et calcul ---------- */

val CAPITAL_COORDS: Map<String, Pair<Double, Double>> = mapOf(
    "La France" to (48.85 to 2.35),
    "Le Japon" to (35.68 to 139.69),
    "Le Brésil" to (-15.79 to -47.88),
    "L'Algérie" to (36.75 to 3.06),
    "Le Maroc" to (34.02 to -6.84),
    "La Tunisie" to (36.81 to 10.17),
    "La Palestine" to (31.77 to 35.21),
    "L'Égypte" to (30.04 to 31.24),
    "L'Arabie Saoudite" to (24.71 to 46.68),
    "La Turquie" to (39.93 to 32.87),
    "L'Italie" to (41.90 to 12.50),
    "L'Allemagne" to (52.52 to 13.40),
    "Les États-Unis" to (38.91 to -77.04),
    "La Chine" to (39.90 to 116.41),
    "L'Inde" to (28.61 to 77.21),
    "L'Espagne" to (40.42 to -3.70),
    "Le Royaume-Uni" to (51.51 to -0.13),
    "La Russie" to (55.76 to 37.62),
    "Le Canada" to (45.42 to -75.70),
    "L'Australie" to (-35.28 to 149.13),
    "La Grèce" to (37.98 to 23.73),
    "Le Mexique" to (19.43 to -99.13),
    "L'Argentine" to (-34.60 to -58.38),
    "La Corée du Sud" to (37.57 to 126.98),
    "Le Qatar" to (25.29 to 51.53),
    "Les Émirats arabes unis" to (24.45 to 54.38),
    "La Suède" to (59.33 to 18.07),
    "Le Kenya" to (-1.29 to 36.82),
    "Le Nigéria" to (9.06 to 7.49),
    "Le Pakistan" to (33.69 to 73.06),
    "L'Indonésie" to (-6.21 to 106.85),
    "La Thaïlande" to (13.76 to 100.50),
    "Le Vietnam" to (21.03 to 105.85)
)

fun haversineKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
    val R = 6371.0
    val dLat = Math.toRadians(b.first - a.first)
    val dLon = Math.toRadians(b.second - a.second)
    val la1 = Math.toRadians(a.first)
    val la2 = Math.toRadians(b.first)
    val h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    return 2 * R * Math.asin(Math.sqrt(h))
}

val COUNTRIES: List<Pair<String, String>> by lazy {
    ALL.filter { it.theme == DRAPEAUX }.map { it.answer to it.icon }
}

data class Theme(val emoji: String, val key: String, val label: String)
